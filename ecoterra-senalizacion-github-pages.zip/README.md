# Mapa de señalización vial — Eco-Terra Maquilishuat, Cluster I

Sitio estático gratuito para consultar el avance de colocación de señales de ALTO.

## Contenido

- `index.html`: página pública.
- `styles.css`: estilos adaptados a PC y celular.
- `app.js`: mapa interactivo, zoom, filtros y edición local.
- `senales.json`: inventario público y estado persistente de cada señal.
- `assets/mapa-cluster1.png`: plano limpio de la residencial.

Incluye **117 posiciones propuestas**, extraídas de los 117 puntos rojos de la imagen proporcionada y alineadas automáticamente al plano limpio. Todas empiezan como **pendientes**; deben revisarse en campo. El total de **70 polígonos** es informativo; los números de polígono de cada señal quedan vacíos hasta su validación.

## Publicación en GitHub Pages

1. Crea un repositorio GitHub (por ejemplo, `mapa-altos-ecoterra`).
2. Sube todos los archivos de esta carpeta, manteniendo `assets/`.
3. Abre **Settings → Pages** y en **Build and deployment** selecciona **Deploy from a branch**, rama `main`, carpeta `/ (root)`.
4. Accede al enlace que GitHub Pages muestre cuando finalice la publicación.
5. Mantén permisos de escritura del repositorio únicamente para administradores de confianza.

**Precaución:** GitHub Pages publica archivos de un repositorio público abiertamente. No incluyas datos personales, contraseñas ni credenciales en el JSON. También puedes publicar desde repositorios privados si las condiciones de tu plan de GitHub lo admiten.

## Cómo actualizar una señal

1. Abre la web y pulsa **Preparar edición**. Esta función está disponible incluso en una visita pública, pero **no publica cambios**: solo prepara una copia local del JSON.
2. Toca una señal y cambia su estado, polígono, fecha u observaciones; también puedes mover, borrar o agregar una señal.
3. Pulsa **Descargar JSON actualizado**.
4. Un colaborador **autorizado** entra en GitHub, reemplaza el contenido de `senales.json` en el repositorio y confirma el cambio (**Commit changes**).
5. GitHub Pages vuelve a publicar automáticamente la web. Los visitantes verán los nuevos estados tras la actualización.

No hay contraseña propia, login falso ni token de GitHub expuesto en el navegador. La autorización ocurre **al publicar al repositorio**, no al editar una copia local. Para evitar que cualquiera vea las herramientas de edición, se requeriría otra arquitectura o una puerta de acceso real (por ejemplo, GitHub OAuth con backend seguro); ocultar un botón no sería seguridad.

## Prueba local

Necesita un servidor HTTP, pues `fetch('senales.json')` no funciona correctamente abriendo el HTML con `file://`.

Con Python instalado, desde esta carpeta:

```bash
python -m http.server 8080
```

Abre `http://localhost:8080` en el navegador.

## Notas

- Los marcadores usan porcentajes `x`, `y` relativos al mapa. Permanecen ubicados al aplicar zoom o utilizar celular.
- Estados: `pendiente`, `proceso`, `instalada`.
- No hay geolocalización real ni indicaciones de tránsito; las ubicaciones deben validarse con las autoridades o responsables técnicos correspondientes antes de instalar señales.
- Si varios editores trabajan en paralelo, coordinen el uso de `senales.json` para evitar sobrescribir cambios de otro administrador.
